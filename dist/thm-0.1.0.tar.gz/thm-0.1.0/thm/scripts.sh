# This file is ran to install scripts and stuff xx
sudo apt install gobuster -y
